import random


# def guess_random_number(tries, start, stop):
#     random_gen = int(random.randint(start, stop))
#     while tries != 0:
#         player_guess = int(input("Guess the Secret Number: "))
#         print(f"Number of Tries Remaining: {tries} ")
#         if player_guess == random_gen:
#             print("Success!!")
#             return
#         if player_guess <= random_gen:
#             print("Guess Higher!")
#         if player_guess >= random_gen:
#             print("Guess Lower!")
#         tries = tries - 1
#         if tries == 0:
#             print(f"You have failed to guess the number: {random_gen}")
#             break

# guess_random_number(5, 0, 10)

# def guess_random_num_linear(tries, start, stop):
#     random_gen = random.randint(start, stop)
#     print("The program is guessing..", random_gen)

#     for x in range(start, stop):
#         if tries == 0:
#             print("Program is out of tries")
#             break
#         if x == random_gen:
#             print("The program guessed the right number")
#             return x
#         if x != random_gen:
#             print("The program continues...")
#         tries -= 1


# guess_random_num_linear(5, 0, 10)

def guess_random_num_binary(tries, start, stop):
    random_gen = random.randint(start, stop)
    lower_bound = start
    upper_bound = stop
    print(f"Random Number to find: {random_gen} ")
    while lower_bound <= upper_bound:
        if tries == 0:
            print("Computer ran out of tries")
            break
        pivot = (lower_bound + upper_bound) // 2
        if pivot == random_gen:
            print(f"Found it! {random_gen}")
            break
        if pivot > random_gen:
            upper_bound = pivot - 1
            print("Guess Lower!")
        if pivot < random_gen:
            lower_bound = pivot + 1
            print("Guess Higher")

        tries -= 1

    return ("Computer Didn't find correct number")


guess_random_num_binary(5, 0, 100)
